
package com.sun.tools.xjc.generator.annotation.spec;

import javax.xml.bind.annotation.XmlID;
import com.sun.codemodel.JAnnotationWriter;

public interface XmlIDWriter
    extends JAnnotationWriter<XmlID>
{


}
